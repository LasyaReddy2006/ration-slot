<?php
include 'connect.php';
$result = $conn->query("SELECT s.date, s.time, u.name FROM slots s JOIN users u ON s.user_id = u.id ORDER BY s.date");
echo "<table border='1'><tr><th>Name</th><th>Date</th><th>Time</th></tr>";
while ($row = $result->fetch_assoc()) {
  echo "<tr><td>{$row['name']}</td><td>{$row['date']}</td><td>{$row['time']}</td></tr>";
}
echo "</table>";
?>