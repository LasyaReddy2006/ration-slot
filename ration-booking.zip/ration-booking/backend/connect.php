<?php
$conn = new mysqli("localhost", "root", "", "ration_booking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>