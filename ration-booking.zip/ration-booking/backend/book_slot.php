<?php
include 'connect.php';
session_start();
$user_id = $_SESSION['user_id'];
$date = $_POST['date'];
$time = $_POST['time'];

$sql = "INSERT INTO slots (user_id, date, time) VALUES ('$user_id', '$date', '$time')";
$conn->query($sql);
echo "Slot booked successfully!";
?>