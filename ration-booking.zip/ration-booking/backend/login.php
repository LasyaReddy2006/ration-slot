<?php
include 'connect.php';
session_start();
$email = $_POST['email'];
$pass = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

if ($user && password_verify($pass, $user['password'])) {
  $_SESSION['user_id'] = $user['id'];
  header("Location: ../book-slot.html");
} else {
  echo "Invalid credentials!";
}
?>