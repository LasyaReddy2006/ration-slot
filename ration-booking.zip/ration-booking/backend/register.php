<?php
include 'connect.php';
$name = $_POST['name'];
$email = $_POST['email'];
$pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
$sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$pass')";
$conn->query($sql);
echo "Registered successfully. <a href='../login.html'>Login</a>";
?>