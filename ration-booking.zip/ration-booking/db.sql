CREATE DATABASE IF NOT EXISTS ration_booking;
USE ration_booking;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE slots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  date DATE,
  time TIME,
  FOREIGN KEY (user_id) REFERENCES users(id)
);